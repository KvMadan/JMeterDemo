package org.md.random;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CopyOnWriteArrayList;



public class RandomFileSampler {
	private static CopyOnWriteArrayList<String[]> list = null;
	private static Random random = new Random();
	
	public static void init(String fileName) throws Exception {
		//read the file into ArrayList
		//TODO charset
		list = new CopyOnWriteArrayList<String[]> (); 
		BufferedReader reader = new BufferedReader( new FileReader(new File(fileName)));
		
	    String line = null;
	    List<String[]> data = new ArrayList<String[]>();
	    while ((line = reader.readLine()) != null) {
	    	//TODO quoted strings
	    	String []  values = line.split(",");
		    data.add(values);
	    }
	    list.addAll(data);
	    reader.close();
	}
	
	public static List<String[]> getVariables(int howMany) {
		List<String[]> result = new ArrayList<String[]>();
		for(int i=0;i<howMany;i++){
			//TODO don't care if same index is used twice
			int index = random.nextInt(list.size());
			
			String[] value = list.get(index);
			result.add(value);
		}
		return result;
	}
	
	
	public static void main(String[] args) throws Exception{
		RandomFileSampler.init("C:/Users/dshetty/Downloads/apache-jmeter-2.13/data/SKU.csv");
		
		for(int i =0 ; i<10;i++) {
			List<String[]> results = RandomFileSampler.getVariables(i);
			for(String[] result : results) {
				for(String val : result) {
					System.out.print(val + " ");
				}
				System.out.println("");
			}
			System.out.println("");
		}
	}
	
	
}
